# Discussion 7 for SI206, Winter 2023

Upload a link to your repo on canvas.

* git status (see what files have been changed and which are staged)
* git add dis7.py (add the file to the staging area for a commit)
* git status (see file in green - staged for a commit)
* git commit -m "message" (take a snapshot labeled with the message)
* git push (put a copy on github)
